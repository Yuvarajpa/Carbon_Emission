const map = L.map('map').setView([23.6345, 78.9629], 5); // Center on India

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

fetch('/api/mines')
    .then(response => response.json())
    .then(data => {
        data.forEach(mine => {
            let marker = L.marker([mine.latitude, mine.longitude]).addTo(map)
                .bindPopup(`<b>${mine.name}</b><br>CO2: ${mine.co2} ppm<br>CH4: ${mine.ch4} ppm`);
        });
    })
    .catch(error => console.error("Error fetching mines:", error));

function searchMine() {
    const query = document.getElementById("search").value.toLowerCase();
    fetch('/api/mines')
        .then(response => response.json())
        .then(data => {
            const result = data.find(mine => mine.name.toLowerCase().includes(query));
            if (result) {
                map.setView([result.latitude, result.longitude], 10);
            } else {
                alert("Mine not found!");
            }
        });
}
